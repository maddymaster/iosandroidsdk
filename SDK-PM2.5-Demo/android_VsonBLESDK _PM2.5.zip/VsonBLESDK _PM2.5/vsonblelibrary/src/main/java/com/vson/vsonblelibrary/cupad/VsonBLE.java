package com.vson.vsonblelibrary.cupad;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

/**
 * Created by vson on 2016/3/11.
 */
public class VsonBLE extends BroadcastReceiver implements BluetoothAdapter.LeScanCallback {

    private static final int REQUEST_ENABLE_BT = 1000;
    private String bleAddress;

    private Activity mActivity;

    private BluetoothAdapter.LeScanCallback mLeScanCallback = this;

    //ble
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothLeService mBluetoothLeService;
    private ArrayList<ArrayList<BluetoothGattCharacteristic>> mGattCharacteristics = new ArrayList<ArrayList<BluetoothGattCharacteristic>>();
    private BluetoothGattCharacteristic characteristic = null;
    public static BluetoothGattCharacteristic characteristicE1 = null;
    public static BluetoothGattCharacteristic characteristicE3 = null;
    public static BluetoothGattCharacteristic characteristicE4 = null;
    public static BluetoothGattCharacteristic characteristicE5 = null;
    public static BluetoothGattCharacteristic characteristicF4 = null;
    public static BluetoothGattCharacteristic characteristicF1 = null;
    public static BluetoothGattCharacteristic characteristicF3 = null;

    private final String LIST_NAME = "NAME";
    private final String LIST_UUID = "UUID";
    private boolean bServiceBind;

    private Handler handler = new Handler();

    private static IntentFilter makeGattUpdateIntentFilter() {
        try {
            final IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
            intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
            intentFilter
                    .addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
            intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
            intentFilter.addAction(BluetoothDevice.ACTION_ACL_CONNECTED);
            return intentFilter;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public VsonBLE(Activity mActivity, BleDevDataCallBack bleDevDataCallBack) {

        this.mActivity = mActivity;
        if (!mActivity.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_BLUETOOTH_LE)) {
            showToast("no ble device！");
            return;
        }

        final BluetoothManager bluetoothManager = (BluetoothManager) mActivity.getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            showToast("Bluetooth error!");
            return;
        }
        setBleDevDataCallBack(bleDevDataCallBack);
        mActivity.registerReceiver(this, makeGattUpdateIntentFilter());
    }

    /**
     * scan ble device
     *
     * @param runnable callback
     */
    public void startScannDevice(Runnable runnable, long SCAN_PERIOD) {
        showLog("startScannDevice-->" + SCAN_PERIOD / 1000 + " s");

        // 为了确保设备上蓝牙能使用, 如果当前蓝牙设备没启用,弹出对话框向用户要求授予权限来启用
        if (!mBluetoothAdapter.isEnabled()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(
                        BluetoothAdapter.ACTION_REQUEST_ENABLE);
                mActivity.startActivityForResult(enableBtIntent,
                        REQUEST_ENABLE_BT);
            }
        }
        scanLeDevice(true);
        new Handler().postDelayed(runnable, SCAN_PERIOD);
    }

    /**
     * scan
     */
    public void scanLeDevice(final boolean enable) {
        showLog("scanLeDevice-->" + enable);
        try {
            if (enable) {
                mBluetoothAdapter.startLeScan(mLeScanCallback);
            } else {
                mBluetoothAdapter.stopLeScan(mLeScanCallback);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @param gattServices
     */
    private void displayGattServices(List<BluetoothGattService> gattServices) {
        try {
            if (gattServices == null)
                return;
            String uuid = null;
            String unknownServiceString = "unknown_service";
            String unknownCharaString = "unknown_characteristic";
            ArrayList<HashMap<String, String>> gattServiceData = new ArrayList<>();
            ArrayList<ArrayList<HashMap<String, String>>> gattCharacteristicData = new ArrayList<>();
            mGattCharacteristics = new ArrayList<>();

            for (BluetoothGattService gattService : gattServices) {
                HashMap<String, String> currentServiceData = new HashMap<>();
                uuid = gattService.getUuid().toString();
                currentServiceData
                        .put(LIST_NAME, SampleGattAttributes.lookup(uuid,
                                unknownServiceString));
                currentServiceData.put(LIST_UUID, uuid);
                gattServiceData.add(currentServiceData);

                ArrayList<HashMap<String, String>> gattCharacteristicGroupData = new ArrayList<>();
                List<BluetoothGattCharacteristic> gattCharacteristics = gattService
                        .getCharacteristics();
                ArrayList<BluetoothGattCharacteristic> charas = new ArrayList<>();

                for (BluetoothGattCharacteristic gattCharacteristic : gattCharacteristics) {
                    charas.add(gattCharacteristic);
                    HashMap<String, String> currentCharaData = new HashMap<>();
                    uuid = gattCharacteristic.getUuid().toString();
                    currentCharaData.put(LIST_NAME, SampleGattAttributes
                            .lookup(uuid, unknownCharaString));
                    currentCharaData.put(LIST_UUID, uuid);
                    gattCharacteristicGroupData.add(currentCharaData);
                }
                mGattCharacteristics.add(charas);
                gattCharacteristicData.add(gattCharacteristicGroupData);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


    /**
     * blueToothConnectService
     *
     * @param bleAddress
     */
    public void blueToothConnectService(String bleAddress) {
        this.bleAddress = bleAddress;
        try {
            Intent gattServiceIntent = new Intent(mActivity,
                    BluetoothLeService.class);
            if (mServiceConnection != null) {
                bServiceBind = mActivity.bindService(gattServiceIntent, mServiceConnection,
                        Context.BIND_AUTO_CREATE);
            }
            //  link_timeout_timer();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * ServiceConnection
     */
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName,
                                       IBinder service) {
            try {
                mBluetoothLeService = ((BluetoothLeService.LocalBinder) service)
                        .getService();
                if (!mBluetoothLeService.initialize()) {
                    mBluetoothLeService.initialize();
                }
                mBluetoothLeService.connect(bleAddress);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            String action = intent.getAction();

            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                bleDevDataCallBack.bleDevConnected(intent);
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED
                    .equals(action)) {
                bleDevDataCallBack.bleDevDisconnected(intent);
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED
                    .equals(action)) {
                reciverDevDiscovered();
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE
                    .equals(action)) {
                bleDevDataCallBack.bleDevDataAvail(intent);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * setCharacteristicNotification
     */
    private void reciverDevDiscovered() {
        showToast("ACTION_GATT_SERVICES_DISCOVERED----------");
        if (mBluetoothLeService == null) {
            return;
        }
        displayGattServices(mBluetoothLeService.getSupportedGattServices());

        if (mGattCharacteristics != null) {

            for (int i = 0; i < mGattCharacteristics.size(); i++) {
                for (int j = 0; j < mGattCharacteristics.get(i).size(); j++) {
                    characteristic = mGattCharacteristics.get(i).get(j);
                    if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_E1)) {
                        characteristicE1 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_E3)) {
                        characteristicE3 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_E4)) {
                        characteristicE4 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_E5)) {
                        characteristicE5 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_F1)) {
                        characteristicF1 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_F3)) {
                        characteristicF3 = characteristic;
                    } else if (characteristic.getUuid().toString()
                            .equals(SampleGattAttributes.UUID_F4)) {
                        characteristicF4 = characteristic;
                    }
                }
            }
            //setCharacteristicNotification
            if (characteristic != null) {
                final int charaProp = characteristic.getProperties();
                if ((charaProp | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {

                    if (mBluetoothLeService == null) {
                        return;
                    }

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mBluetoothLeService == null) {
                                return;
                            }
                            mBluetoothLeService.setCharacteristicNotification(
                                    characteristicF4, true);
                        }
                    }, 0);

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mBluetoothLeService == null) {
                                return;
                            }
                            mBluetoothLeService.setCharacteristicNotification(
                                    characteristicE3, true);
                        }
                    }, 500);

                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mBluetoothLeService == null) {
                                return;
                            }
                            mBluetoothLeService.setCharacteristicNotification(
                                    characteristicE4, true);
                        }
                    }, 1000);
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mBluetoothLeService == null) {
                                return;
                            }
                            mBluetoothLeService.setCharacteristicNotification(
                                    characteristicE1, true);
                        }
                    }, 1500);
                }
            }
        }

        handler.postDelayed(new Runnable() {
            public void run() {
                send_pass_to_device();
            }
        }, 2000);
    }

    /**
     * must send ,no change
     */
    public void send_pass_to_device() {
        byte[] bapass = new byte[18];
        int i = 0;
        String strpass = "";
        int numcode1 = (int) ((Math.random() * 9 + 1) * 100000);
        String random = "" + numcode1;
        strpass = random;
        byte[] temp = strpass.getBytes();

        bapass[0] = 0x00;
        bapass[1] = 0x01;

        for (i = 2; i < 8; i++)
            bapass[i] = temp[i - 2];

        for (i = 8; i < 18; i++)
            bapass[i] = 0x00;

        send_data_to_device(characteristicF1, bapass);
    }

    private byte eValue = -1; // battery value

    /**
     * FFF4
     * <p/>
     * 1.when get 120 then send 0x03 to get ready receive data
     * 2.none 120 ,the battery value
     *
     * @param vv
     */
    public void FFF4Data(byte[] vv) {
        try {
            eValue = vv[0];
            //when get 120 then send 0x03 to get ready receive data
            if (eValue == 120) {
                byte[] b = {3};//request data
                send_data_to_device(characteristicF3, b);
            } else {
                if (eValue > 100) {
                    eValue = 100;
                } else if (eValue < 0) {
                    eValue = 0;
                }
                int i = eValue / 10;
                //setBattery(i);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void send_FFE5_data_to_device() {

        // time data to the device
        final byte[] b = new byte[6];
        b[0] = 0x01;
        //str=2015-12-23-10-04
        long appDbTime = 201611101347L;//lastRecordTime
        //long devTime = Long.parseLong(str);
        showLog("appDbTime:" + appDbTime);

        b[1] = (byte) (appDbTime / 100000000 % 100);
        b[2] = (byte) (appDbTime / 1000000 % 100);
        b[3] = (byte) (appDbTime / 10000 % 100);
        b[4] = (byte) (appDbTime / 100 % 100);
        b[5] = (byte) (appDbTime % 100);

        /**
         * request data
         * */
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                send_data_to_device(VsonBLE.characteristicE5, b);
            }
        }, 6000);
        //   send_data_to_device(characteristicE5, b);
        showLog("send b------" + Arrays.toString(b));
    }

    /**
     * Init device
     */
    public void send_FFF1_data_to_device() {
        try {
            int _vulumeSql = 1600;
            byte _intervalSql = (byte) 30;
            byte[] value = new byte[11];

            Calendar c = Calendar.getInstance();
            byte year = (byte) (c.get(Calendar.YEAR) - 2000);
            byte month = (byte) (c.get(Calendar.MONTH) + 1);
            byte day = (byte) (c.get(Calendar.DAY_OF_MONTH));
            byte hour = (byte) (c.get(Calendar.HOUR_OF_DAY));
            byte min = (byte) (c.get(Calendar.MINUTE));
            byte sec = (byte) (c.get(Calendar.SECOND));
            byte[] _volumear = shortToByteArray((short) (_vulumeSql));
            byte[] _intervalSql_ar = shortToByteArray((short) (_intervalSql));

            value[0] = year;
            value[1] = month;
            value[2] = day;
            value[3] = hour;
            value[4] = min;
            value[5] = sec;
            value[6] = (byte) 0;
            value[7] = _volumear[0];
            value[8] = _volumear[1];
            value[9] = _intervalSql_ar[0];
            value[10] = _intervalSql_ar[1];

            send_data_to_device(characteristicF1, value);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * @param s
     * @return targets
     */
    private byte[] shortToByteArray(short s) {
        byte[] targets = new byte[2];
        for (int i = 0; i < 2; i++) {
            int offset = (targets.length - 1 - i) * 8;
            targets[i] = (byte) ((s >>> offset) & 0xff);
        }
        return targets;
    }

    /**
     * send data to device
     *
     * @param characteristic BluetoothGattCharacteristic
     * @param b              data
     */
    public void send_data_to_device(BluetoothGattCharacteristic characteristic, byte[] b) {
        if (mGattCharacteristics == null) {
            return;
        }

        if (characteristic != null) {
            characteristic.setValue(b);
            if (mBluetoothLeService != null) {
                mBluetoothLeService.wirteCharacteristic(characteristic);
            }
        }
    }

    /**
     * reset ble
     */
    public void reSetBle() {

        if (mBluetoothLeService != null) {
            mBluetoothLeService.disconnect();
            mActivity.unbindService(mServiceConnection);
            mBluetoothLeService = null;
            bServiceBind = false;
        }
    }

    public BleDevDataCallBack bleDevDataCallBack;

    public BleDevDataCallBack getBleDevDataCallBack() {
        return bleDevDataCallBack;
    }

    public void setBleDevDataCallBack(BleDevDataCallBack bleDevDataCallBack) {
        this.bleDevDataCallBack = bleDevDataCallBack;
    }

    @Override
    public void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord) {
        bleDevDataCallBack.onLeScan(device, rssi, scanRecord);
    }

    public interface BleDevDataCallBack {
        void onLeScan(BluetoothDevice device, int rssi, byte[] scanRecord);

        void bleDevConnected(Intent intent);

        void bleDevDataAvail(Intent intent);

        void bleDevDisconnected(Intent intent);

    }

    private void showLog(String s) {
        Log.e("VsonBle-->", s);
    }


    private void showToast(String str) {
        Toast.makeText(mActivity, str, Toast.LENGTH_SHORT).show();
    }

    /**
     * close app
     */
    public void onBleDestroy() {
        try {
            if (bServiceBind) {
                mActivity.unbindService(mServiceConnection);
            }
            mBluetoothLeService = null;
            if (this != null) {
                mActivity.unregisterReceiver(this);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
