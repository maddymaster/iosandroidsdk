package com.vson.vsonbledemo;


import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ScanBluetoothAdapter extends BaseAdapter {

    private final ArrayList<String> btName, btAddress;
    //private List<BluetoothDevice> bluetoothDevices;
    private LayoutInflater mInflater;
    private Context con;

    public ScanBluetoothAdapter(Context context, ArrayList<String> btName, ArrayList<String> btAddress) {
        mInflater = LayoutInflater.from(context);
        this.con = context;
        this.btName = btName;
        this.btAddress = btAddress;
    }

    @Override
    public int getCount() {
        return btAddress.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolderScanBT holder = null;
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.listitem_scanbluetooth, null);
            holder = new ViewHolderScanBT();
            holder.tvName = (TextView) convertView.findViewById(R.id.btName);
            holder.tvAddress = (TextView) convertView.findViewById(R.id.btAddress);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolderScanBT) convertView.getTag();
        }
        if (btName.size() > 0) {
            holder.tvName.setVisibility(View.VISIBLE);
            String name = btName.get(position);
            if (Integer.parseInt(name.split("#")[3].split(":")[1]) >= 40) {
                holder.tvName.setTextColor(Color.GREEN);
            } else {
                holder.tvName.setTextColor(Color.RED);
            }
            holder.tvName.setText(name);
        } else {
            holder.tvName.setVisibility(View.GONE);
        }
        holder.tvAddress.setText(btAddress.get(position));
        return convertView;
    }
}

class ViewHolderScanBT {
    TextView tvName;
    TextView tvAddress;
}


