package com.vson.vsonbledemo;

import android.Manifest;
import android.annotation.TargetApi;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.vson.vsonblelibrary.cupad.BluetoothLeService;
import com.vson.vsonblelibrary.cupad.VsonBLE;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity implements VsonBLE.BleDevDataCallBack, AdapterView.OnItemClickListener {
    private ListView lvScanBluetooth;
    private ScanBluetoothAdapter scanAdapter;
    private TextView bleStatus;
    private Button scan, disBle;

    private ArrayList<String> btName = new ArrayList<String>();
    private ArrayList<String> btAddress = new ArrayList<String>();

    private String bleName, bleAddress;

    private VsonBLE vsonBLE = null;
    private byte[] vv;//ble data
    private StringBuffer stringBuffer;
    private DecimalFormat df;
    private long lastRecordTime;
    private int lastIndex = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread thread, Throwable ex) {
                ex.printStackTrace();
            }
        });
        initView();
        initData();
    }

    private void initView() {

        stringBuffer = new StringBuffer();
        df = new DecimalFormat("00");

        lvScanBluetooth = (ListView) findViewById(R.id.lvScanBluetooth);
        bleStatus = (TextView) findViewById(R.id.ble_status);
        scan = (Button) findViewById(R.id.scan);
        disBle = (Button) findViewById(R.id.goMain);

        scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startScanDevice();
            }
        });
        disBle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vsonBLE.reSetBle();
            }
        });
        scanAdapter = new ScanBluetoothAdapter(this, btName, btAddress);
        lvScanBluetooth.setAdapter(scanAdapter);

        lvScanBluetooth.setOnItemClickListener(this);
    }

    private void initData() {
        vsonBLE = new VsonBLE(MainActivity.this, this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            initPermission();
        } else {
            startScanDevice();
        }
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (btAddress.size() > 0 || btName.size() > 0) {
                lvScanBluetooth.setAdapter(scanAdapter);
                scanAdapter.notifyDataSetChanged();
            } else {
                showToast("no found device !");
            }
        }
    };

    private Timer timer;
    public static final long SCAN_PERIOD = 10000;//ble scan period

    private void startScanDevice() {
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.sendMessage(handler.obtainMessage());
            }
        }, 1000, 1000);

        btName.clear();
        btAddress.clear();
        lvScanBluetooth.deferNotifyDataSetChanged();
        lvScanBluetooth.setEnabled(true);
        vsonBLE.reSetBle();
        vsonBLE.startScannDevice(new Runnable() {
            @Override
            public void run() {
               /*
                if (btAddress.size() > 0) {
                    scanAdapter.notifyDataSetChanged();
                } else {
                    showToast("no found device !");
                }*/
            }
        }, SCAN_PERIOD);
    }

    // scan device callback
    @Override
    public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    String nameStr = device.getName() + "#rssi:" + (rssi + 100);
                    String addressStr = device.getAddress();

                    //name  VSON#WP2810#XXXXXX#rssi:-92
                    if ((nameStr == null) || (nameStr.length() <= 10))
                        return;

                    String[] ns = nameStr.split("#");

                    if (btAddress.contains(addressStr)) {
                        for (int i = 0; i < btAddress.size(); i++) {
                            if (addressStr.equals(btAddress.get(i))) {
                                btName.set(i, nameStr);
                            }
                        }
                    } else {
                        if (ns.length == 4) {
                            btName.add(nameStr);
                            btAddress.add(addressStr);
                            //bluetoothDevices.add(device);
                        }
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

    /**
     * select device to start
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        try {
            //showToast("click the position --" + position);
            timer.cancel();
            vsonBLE.scanLeDevice(false);
            bleAddress = btAddress.get(position);
            bleName = btName.get(position).split("#")[2];
            btName.clear();
            btAddress.clear();

            vsonBLE.blueToothConnectService(bleAddress);
            scanAdapter.notifyDataSetChanged();
            lvScanBluetooth.setEnabled(true);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void bleDevConnected(Intent intent) {
        //  showToast("ACTION_GATT_CONNECTED");
        bleStatus.setText("device Connected");
    }

    @Override
    public void bleDevDataAvail(Intent intent) {
        //   showToast("ACTION_DATA_AVAILABLE");
        bleStatus.setText("device connected");
        // get the cup data
        vv = intent.getByteArrayExtra(BluetoothLeService.EXTRA_DATA);
        btAddress.add("receive data:\n" + Arrays.toString(byteToIntE1Data(vv)));
        handler.sendMessage(handler.obtainMessage());
        Log.e("vv--->", Arrays.toString(byteToIntE1Data(vv)));
        if (vv == null || vv.length == 0) {
            return;
        }
        if (vv.length == 1) {
            vsonBLE.FFF4Data(vv);
            if (vv[0] == 120) {
                btAddress.add("send data:\n when get 【120】,send 03-" + "characteristicF3-->03");
            }
        }
        // ffe3通道
        if (vv.length == 2) {
            if ((vv[0] == 0x01) && (vv[1] == 0x01)) {
                //init device  time
                btAddress.add("send data:\n when get 【01,01】," + " characteristicF1-->init data");
                vsonBLE.send_FFF1_data_to_device();
            } else if ((vv[0] == 0x02) && (vv[1] == 0x19)) {

                showLog("history data send over");
            }
        }
        if (vv.length == 8) {
            //data_vv----->>﹕ [1, -1, 15, 31, 127, -1, 0, 0]

            //no data
            if (vv[6] == 0 && vv[7] == 0) {
                return;
            }
            //  data_vv----->>﹕ [1, 15, 12, 23, 10, 30, 0, 120]
            //send lastRecordTime to device ,the device will send the pm2.5 value to app ,if it has data
            vsonBLE.send_FFE5_data_to_device();
        }

        if (vv.length == 20) {
//               showLog("data_vvv----->> ", Arrays.toString(vv));
            stringBuffer.delete(0, stringBuffer.length());
            stringBuffer
                    .append(2000 + Integer.parseInt((df.format(vv[0]))))
                    .append("-")
                    .append(df.format(vv[1]))
                    .append("-")
                    .append(df.format(vv[2]))
                    .append(" ")
                    .append(df.format(vv[3]))
                    .append(":")
                    .append(df.format(vv[4]));//2015-12-23 10：30
            String str1 = stringBuffer.toString();
            String str = str1.replace("-", "").replace(" ", "").replace(":", "");
            stringBuffer.delete(0, stringBuffer.length());

            if (str.equals("200000000000")) {
                return;
            }

            int[] vvv = byteToIntE1Data(vv);
            if (lastIndex != vvv[18]) {
                lastIndex = vvv[18];
            } else {
                return;
            }
            if (vvv[5] * 256 + vvv[6] > 1000) {
                return;
            }
            /**
             * 0: history data ,may be a lot
             * [16, 1, 12, 11, 12,       2, -36,   7,  38,   12, 100,   72,-83,  0,0,0,0,0,   7, 1]
             *
             *   pm2.5 value : vvv[5]*256+vvv[6]
             * */
            if (vv[19] == 0) {
                //save data   time:  str,  value: vvv[5] * 256 + vvv[6]

                btAddress.add("send data:\n 【15】 to get more history data ," + "characteristicF3-->get more history data");
                byte[] b = {15};//request data one by one
                vsonBLE.send_data_to_device(VsonBLE.characteristicF3, b);
            }
            /**
             * 1: now
             *     20/min  3s
             *   [16, 1, 12, 11, 12,   2,-36, 7, 38, 12, 100,72,-83, 0,0, 0, 0, 0, 7, 1]
             *   pm2.5 value : vvv[5]*256+vvv[6]
			   pm1 = vvv[7] * 256 + vvv[8];
			   pm10 = vvv[9] * 256 + vvv[10];
			   //颗粒物和PM25的关系值：  颗粒物 ＝ pm2.5 ＊ 6250 ＊ 3.53/1000      显示的时候带单位： k
			   pmkl = (int) (pm25 * 6250 * 3.53 / 1000);
				
             * */
            else if (vv[19] == 1) {

                //lastRecordTime = getSharedPreferences(Util.APP_MAIN, Context.MODE_PRIVATE).getLong(Util.LAST_RECORD_TIME, lastRecordTime);
                lastRecordTime = 201611101340L;

                if (lastRecordTime == 0) {
                    //saveRecord(str,vvv);
                    //getSharedPreferences(Util.APP_MAIN, Context.MODE_PRIVATE).edit().putLong(Util.LAST_RECORD_TIME, Long.parseLong(str)).apply();
                    showLog("first data ");
                } else {
                    //you can define yourself
                        /* if (Long.parseLong(str) - Long.parseLong(Util.add15MinByTime(String.valueOf(lastRecordTime), 0)) >= 0) {
                             showLog("Time to write");
                             //getSharedPreferences(Util.APP_MAIN, Context.MODE_PRIVATE).edit().putLong(Util.LAST_RECORD_TIME, Long.parseLong(str)).apply();
                             // saveRecord(str,vvv);
                         } else {
                                 showLog( "repeat data , give up");
                            }*/
                }
            }
        }
    }

    @Override
    public void bleDevDisconnected(Intent intent) {
        //  showToast("ACTION_GATT_DISCONNECTED");
        bleStatus.setText("device disConnected");
    }

    @TargetApi(23)
    private void initPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            //showRequestPermissionWriteSettings();
            // Android M Permission check 
            if (this.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
            } else if (this.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_ACCESS_FINE_LOCATION);
            } else if (this.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_READ_EXTERNAL_STORAGE);
            } else if (this.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE);
            } else {
                startScanDevice();
            }
        }
    }

    private static final int PERMISSION_REQUEST_COARSE_LOCATION = 1;
    private static final int PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE = 2;
    private static final int PERMISSION_REQUEST_ACCESS_FINE_LOCATION = 3;
    private static final int PERMISSION_REQUEST_READ_EXTERNAL_STORAGE = 4;

    @TargetApi(23)
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_COARSE_LOCATION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initPermission();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
                }
                break;
            case PERMISSION_REQUEST_ACCESS_FINE_LOCATION: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initPermission();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSION_REQUEST_ACCESS_FINE_LOCATION);
                }
                break;
            }
            case PERMISSION_REQUEST_READ_EXTERNAL_STORAGE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initPermission();
                } else {
                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_REQUEST_READ_EXTERNAL_STORAGE);
                }
                break;
            }
            case PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    initPermission();
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_REQUEST_COARSE_LOCATION);
                }
                break;
            }
        }
    }


    public static int[] byteToIntE1Data(byte[] vv) {

        int[] vvv = new int[vv.length];
        for (int i = 0; i < vv.length; i++) {
            if (vv[i] < 0) {
                vvv[i] = vv[i] + 256;
            } else {
                vvv[i] = vv[i];
            }
        }
        return vvv;
    }

    private void showToast(String str) {
        Toast.makeText(MainActivity.this, str, Toast.LENGTH_SHORT).show();
    }

    public static final String TAG = "MainActivity----";

    private void showLog(String str) {
        if (BuildConfig.DEBUG) {
            Log.e(TAG, str);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        vsonBLE.onBleDestroy();
    }
}

