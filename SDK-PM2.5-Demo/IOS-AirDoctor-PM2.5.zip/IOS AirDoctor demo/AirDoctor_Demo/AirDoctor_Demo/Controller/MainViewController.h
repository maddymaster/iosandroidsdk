//
//  MainViewController.h
//  AirDoctor_Demo
//
//  Created by kakaxi on 2016/11/10.
//  Copyright © 2016年 VSON. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Device.h"
@interface MainViewController : UIViewController

@property(nonatomic , strong) Device *m_device;

@end
