//
//  ScanViewController.h
//  AirDoctor_Demo
//
//  Created by kakaxi on 2016/11/10.
//  Copyright © 2016年 VSON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanViewController : UIViewController

@end
