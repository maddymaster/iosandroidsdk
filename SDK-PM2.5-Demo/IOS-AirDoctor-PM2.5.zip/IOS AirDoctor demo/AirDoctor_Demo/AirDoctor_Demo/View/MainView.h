//
//  MainView.h
//  AirDoctor_Demo
//
//  Created by kakaxi on 2016/11/10.
//  Copyright © 2016年 VSON. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIView


@property(nonatomic , strong) UITextView *m_view_battery;
@property(nonatomic , strong) UITextView *m_view_dataNow;
@property(nonatomic , strong) UITextView *m_view_dataHistory;

@end
